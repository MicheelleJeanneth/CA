﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Main_Form : Form
    {
        Form1 form1;
        DataTable dtuser;
        Add_User adduser;
        string a;
        public Main_Form(Form form,DataTable dtuser, string a)
        {
            InitializeComponent();
            timer1.Start();
            this.form1 = (Form1)form;
            this.dtuser = dtuser;
            this.a = a;
        }

        private void Main_Form_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = a;
        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = DateTime.Now.ToString("ddd, dd - MM - yyy HH:mm:ss");
        
        }

        private void AddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            adduser = new Add_User();
            adduser.MdiParent = this;
            adduser.Show();
        }

        private void LoginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form1.closeform2();
            form1.Show();
        }

        public void form1close()
        {
            form1.Hide();
        }
    }
}
