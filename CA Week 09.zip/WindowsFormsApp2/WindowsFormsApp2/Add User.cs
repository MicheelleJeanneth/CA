﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Add_User : Form
    {
        //DataTable dtuser;
        public Add_User()
        {
            InitializeComponent();
        }

        private void Add_User_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_adduser_Click(object sender, EventArgs e)
        {
            bool sama = false;
            bool pass = false;

            if (txbx_passadd.Text == txbx_confirmadd.Text)
            {
                for (int i = 0; i < Form1.dtuser.Rows.Count; i++)
                {
                    if (txbx_useradd.Text == Form1.dtuser.Rows[i][0].ToString())
                    {
                        sama = true;
                        break;
                    }
                }
                if (sama == true)
                {
                    MessageBox.Show("User already exist");
                    sama = false;
                    txbx_useradd.Text = "";
                    txbx_passadd.Text = "";
                    txbx_confirmadd.Text = "";
                }
                else
                {
                    MessageBox.Show("User added");
                    Form1.dtuser.Rows.Add(txbx_useradd.Text, txbx_passadd.Text);
                    txbx_useradd.Text = "";
                    txbx_passadd.Text = "";
                    txbx_confirmadd.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Password not match");
            }

            
           
            
        }
    }
}
