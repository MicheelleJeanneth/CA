﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {

        public static DataTable dtuser = new DataTable();
        string a = "";
        int userke = 0;
        Main_Form mainform;
        public Form1()
        {
            InitializeComponent();
            dtuser.Columns.Add("Username");
            dtuser.Columns.Add("Password");
            dtuser.Rows.Add("admin", "admin");
        }

        private void txbx_userlogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void txbx_passlogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
        public void closeform2() 
        {
            mainform.Hide();    
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            bool daftar = false;
            bool password = false;
            for (int i = 0; i < dtuser.Rows.Count; i++)
            {
                if (txbx_passlogin.Text == dtuser.Rows[i][1].ToString())
                {
                    if (txbx_userlogin.Text == dtuser.Rows[i][0].ToString())
                    {
                        daftar = true;
                        password = true;
                        userke = i;
                        break;
                    }
                    else
                    {
                        daftar = true;
                        password = false;
                        break;
                    }
                }

            }
            if (daftar == true && password == true)
            {
                a = txbx_userlogin.Text;
                mainform = new Main_Form(this, dtuser, a);
                mainform.Show();
                mainform.form1close();
            }
            else
            {
                MessageBox.Show("Incorrect");
            }
            txbx_userlogin.Text = "";
            txbx_passlogin.Text = "";
        }
    }
    
}
